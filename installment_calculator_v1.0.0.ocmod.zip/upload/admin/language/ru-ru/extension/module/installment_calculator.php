<?php
$_['heading_title'] = 'Калькулятор рассрочки';
$_['text_edit'] = 'Настройки';
$_['text_extension'] = 'Расширения';
$_['text_success'] = 'Настройки сохранены';
$_['text_enabled'] = 'Включено';
$_['text_disabled'] = 'Выключено';
$_['entry_status'] = 'Статус';
$_['entry_months'] = 'Периоды (месяцы)';
$_['entry_email'] = 'Email для заявок';
$_['button_save'] = 'Сохранить';
$_['button_cancel'] = 'Отмена';
$_['error_permission'] = 'Нет прав доступа';